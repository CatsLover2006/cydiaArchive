#!/bin/bash
#
#Cheat Utility v0.06-3
#Scripted by Zamda for iphonecheating.com.
#Decrypt is based off PoedCrackMod.
#Want to add a cheat? PM me at xSellize or iphonecheating.com
#Credit given to cheat discoverers where due :)
#
#Remember to define AppName, AppPath, AppExec, reqver.
#echo "Welcome to CheatUtility :)"

if [[ $EUID -ne 0 ]]; then
   echo "Run CheatUtility in root. Type su > password (default password is alpine)" 1>&2
   exit 1;
fi

##Depends

if [ ! -e /usr/bin/plutil ]; then echo "You don't have plutil. Install Erica Utilities from Cydia."; exit 1; fi
if [ ! -e /usr/bin/awk ]; then echo "You don't have awk. Install gawk from Cydia."; exit 1; fi
if [ ! -e /usr/bin/ldid ]; then echo "You don't have ldid. Install Link Identity Editor from Cydia (make sure you have developer filter switched on)."; exit 1; fi
if [ ! -e /usr/bin/gdb ]; then echo "You don't have gdb. Install GNU Debugger from Cydia (make sure you have developer filter switched on)."; exit 1; fi
if [ ! -e /usr/bin/otool ]; then echo "You don't have otool. Install toolchain from Cydia (make sure you have developer filter switched on)."; exit 1; fi

##Core Functions

function decrypt { 
echo "Binary Decrypter. 100% based poedCrack. Thanks to PoedGirl and everyone else who worked on it."
WorkDir="/tmp/appdecrypttmp"
if [ -e "$WorkDir" ]; then
        rm -rf "$WorkDir"
fi
mkdir -p "$WorkDir"
PCMarm7onarm7="YES"
SwapSwapAttack="NO"

echo "and copying some files"
mkdir -p "$WorkDir/$AppName"
cp -a "$AppPath/$AppName/$AppExec" "$AppPath/$AppName/$AppExec.encryptbak"
cp -a "$AppPath/$AppName/$AppExec" "$WorkDir/$AppName/"
cp -a "$AppPath/$AppName/Info.plist" "$WorkDir/$AppName/"

echo -n "Analyzing application: "

LipoFail=$(lipo -info "$WorkDir/$AppName/$AppExec" | grep Architectures | awk '{print $2}')
if [ ! $LipoFail ]; then
    echo "Thin Binary found"
    Iterations=1
else
    echo "Fat Binary found"

    echo "Dumping armv6 section"
    lipo -thin armv6 "$WorkDir/$AppName/$AppExec" -output "$WorkDir/$AppName/IWantYourSix"
    chmod 777 "$WorkDir/$AppName/IWantYourSix"

    if [ ! $CPUType ]; then
        if [ $PCMarm7onarm7 = "YES" ]; then
            echo "Dumping armv7 section"
            Iterations=2
            foo=$(echo -ne "\x09" | dd bs=1 seek=15 conv=notrunc status=noxfer of="$WorkDir/$AppName/$AppExec" 2>&1> /dev/null)
            foo=$(echo -ne "\x06" | dd bs=1 seek=35 conv=notrunc status=noxfer of="$WorkDir/$AppName/$AppExec" 2>&1> /dev/null)
            lipo -thin armv6 "$WorkDir/$AppName/$AppExec" -output "$WorkDir/$AppName/SevenTrumpets"
            chmod 777 "$WorkDir/$AppName/SevenTrumpets"
        else
            echo "Armv7 compatible CPU but not dumping armv7"
            Iterations=1
        fi
    else
        echo "Non armv7 compatible CPU: not dumping armv7"
        Iterations=1
    fi
fi
for (( i=1;i<=$Iterations;i++)); do
    if [ ! $LipoFail ]; then
        AppExecCur=$AppExec
    else
        if [ $i -eq 1 ]; then
            AppExecCur="IWantYourSix"
            echo "${Meter30}--- Cracking armv6 section ---"
            Patched="$Patched arm6"
        else
            AppExecCur="SevenTrumpets"
            echo "${Meter30}--- Cracking armv7 section ---"
            Patched="$Patched arm7"
        fi
    fi
    CryptSize=$(otool -l "$WorkDir/$AppName/$AppExecCur" | grep cryptsize | awk '{print $2}')
    if [ ! $CryptSize ]; then
        echo "Unable to find CryptSize"
        rm -fr "$WorkDir"
        exit 1
    fi
    CryptOff=$(otool -l "$WorkDir/$AppName/$AppExecCur" | grep cryptoff | awk '{print $2}')
    if [ ! $CryptOff ]; then
        echo "Unable to find CryptOff"
        rm -fr "$WorkDir"
        exit 1
    fi

    echo "Locating and patching CryptID"
    dd bs=4096 count=1 if="$WorkDir/$AppName/$AppExecCur" 2> /dev/null | \
    od -A n -t x1 -v | \
    tr -d ' ','\n' | \
    sed "s/0000002100000014......................01.*/ThisIsItThisIsItThisIsItThisIsItHere!!/g" > "$WorkDir/hex.tmp"
    foo=$(echo -ne "\x00" | dd bs=1 seek=$(expr $(($(stat -c%s "$WorkDir/hex.tmp"))) / 2) conv=notrunc status=noxfer of="$WorkDir/$AppName/$AppExecCur" 2>&1> /dev/null)
    rm -f "$WorkDir/hex.tmp"
    cid=$(otool -l "$WorkDir/$AppName/$AppExecCur" | grep cryptid | awk '{print $2}')

    if [ $cid = "1" ]; then
        echo "Unable to patch CryptID"
        rm -fr "$WorkDir"
        exit 1
    fi

    # Creating GDB script
    echo -e "set sharedlibrary load-rules \".*\" \".*\" none\r\n\
    set inferior-auto-start-dyld off\r\n\
    set sharedlibrary preload-libraries off\r\n\
    set sharedlibrary load-dyld-symbols off\r\n\
    handle all nostop\r\n\
    rb doModInitFunctions\r\n
    command 1\r\n\
    dump memory $WorkDir/dump.bin 0x2000 $(($CryptSize + 0x2000))\r\n\
    kill\r\n\
    quit\r\n\
    end\r\n\
    start" > $WorkDir/batch.gdb

    SwapSwapAttack="NO"
    if [ $i -eq 1 ]; then
        if [ $LipoFail ]; then
            if [ ! $CPUType ]; then
                echo "${Meter39}Swap Swap Attack !"
                SwapSwapAttack="YES"
            fi
        fi
    fi

    echo "Dumping unencrypted data from application"

    if [ $SwapSwapAttack = "YES" ]; then
        # Copying some files
        mkdir "$WorkDir/$AppName/SC_Info"
        chmod 777 "$WorkDir/$AppName/SC_Info"
        cp "$AppPath/$AppName/SC_Info/$AppExec.sinf" "$WorkDir/$AppName/SC_Info/$AppExec.sinf"
        chmod 777 "$WorkDir/$AppName/SC_Info/$AppExec.sinf"
        cp "$AppPath/$AppName/SC_Info/$AppExec.supp" "$WorkDir/$AppName/SC_Info/$AppExec.supp"
        chmod 777 "$WorkDir/$AppName/SC_Info/$AppExec.supp"
        cp "$AppPath/$AppName/ResourceRules.plist" "$WorkDir/$AppName/ResourceRules.plist"
        chmod 777 "$WorkDir/$AppName/ResourceRules.plist"
        mkdir "$WorkDir/$AppName/_CodeSignature"
        chmod 777 "$WorkDir/$AppName/_CodeSignature"
        cp "$AppPath/$AppName/_CodeSignature/CodeResources" "$WorkDir/$AppName/_CodeSignature/CodeResources"
        chmod 777 "$WorkDir/$AppName/_CodeSignature/CodeResources"
        ln -s "$WorkDir/$AppName/_CodeSignature/CodeResources" "$WorkDir/$AppName/CodeResources"

        # Cracking the previously swapped fat binary in WorkDir
        foo=$(gdb -q -e "$WorkDir/$AppName/$AppExec" -x $WorkDir/batch.gdb -batch > /dev/null 2>&1> /dev/null)

        # Removing temp files
        rm "$WorkDir/$AppName/$AppExec"
        rm "$WorkDir/$AppName/SC_Info/$AppExec.sinf"
        rm "$WorkDir/$AppName/SC_Info/$AppExec.supp"
        rmdir "$WorkDir/$AppName/SC_Info"
        rm "$WorkDir/$AppName/ResourceRules.plist"
        rm "$WorkDir/$AppName/CodeResources"
        rm "$WorkDir/$AppName/_CodeSignature/CodeResources"
        rmdir "$WorkDir/$AppName/_CodeSignature"
    else
        # Cracking genuine executable in AppPath
        foo=$(gdb -q -e "$AppPath/$AppName/$AppExec" -x $WorkDir/batch.gdb -batch > /dev/null 2>&1> /dev/null)
    fi

    # Not needed anymore
    rm $WorkDir/batch.gdb

    echo -n "${Meter50}Verifying dump "
    if [ ! -e "$WorkDir/dump.bin" ]; then
        echo "failed ! Can't dump ?"
        rm -fr "$WorkDir"
        exit 1
    fi
    DumpSize=$(stat -c%s "$WorkDir/dump.bin")
    if [ "$DumpSize" != "$CryptSize" ]; then
        echo "failed ! Wrong size ?"
        rm -fr "$WorkDir"
        exit 1
    fi

    echo "${Meter54}and replacing encrypted data"
    foo=$(dd seek=1 count=1 obs=4096 ibs=$DumpSize conv=notrunc if="$WorkDir/dump.bin" of="$WorkDir/$AppName/$AppExecCur" 2>&1> /dev/null)
    rm "$WorkDir/dump.bin"

    echo "${Meter60}Signing the application"
    foo=$(ldid -s "$WorkDir/$AppName/$AppExecCur" 2>&1> /dev/null)
done
if [ $LipoFail ]; then
    rm -f "$WorkDir/$AppName/$AppExec"
    echo "${Meter61}---"
    if [ -e "$WorkDir/$AppName/SevenTrumpets" ]; then
        echo "${Meter62}Combining both parts into a fat binary"
        lipo -create "$WorkDir/$AppName/IWantYourSix" "$WorkDir/$AppName/SevenTrumpets" -output "$WorkDir/$AppName/$AppExec"
        chmod 777 "$WorkDir/$AppName/$AppExec"

        if [ $PCMkeepunpatched != "YES" ]; then
            rm "$WorkDir/$AppName/IWantYourSix"
            rm "$WorkDir/$AppName/SevenTrumpets"
        fi
    else
        mv "$WorkDir/$AppName/IWantYourSix" "$WorkDir/$AppName/$AppExec"
        chmod 777 "$WorkDir/$AppName/$AppExec"
    fi
fi
touch -r "$AppPath/$AppName/$AppExec" "$WorkDir/$AppName/$AppExec"
echo "Swapping binaries"
rm -f $AppPath/$AppName/$AppExec
cp $WorkDir/$AppName/$AppExec $AppPath/$AppName/$AppExec
rm -rf $WorkDir
echo "Application succesfully decrypted!" 
sign
echo "Mods by DarkFurry5 & Intyre, CheatUtility by Zamda [www.iphonecheating.com]"
}

function encryptioncheck { 
echo "Checking Encryption."
CryptID=$(otool -l "$AppPath/$AppName/$AppExec" | grep cryptid | awk '{print $2}')
if [ $CryptID -eq "1" ]; then decrypt; else echo "Done."; exit; fi 
}

function versioncheck {
ver=$(plutil -key CFBundleVersion "$AppPath/$AppName/Info.plist" 2>&1)
if [ "$ver" != "$reqver" ]; then echo "You have version $ver of this app. You need version $reqver for this cheat to work."; exit; fi 
}

function patch {
printf "$input" | dd seek=$((0x$offset)) of=$AppPath/$AppName/$AppExec bs=1 conv=notrunc 
}

function sign {
echo "Signing."
ldid -s "$AppPath/$AppName/$AppExec"
chmod 755 "$AppPath/$AppName/$AppExec" 
}

##With that out of the way, let's get this party started!

case $1 in

"")
clear
AppPath="$(dirname /User/Applications/*/minecraftpe.app)"
AppName="minecraftpe.app"
AppExec="minecraftpe"
reqver="0.3.0.0"
versioncheck; encryptioncheck
;;
esac
exit

