*This is a developers template pack that has everything you need to make an HD graphic for you toggle*
If you have any questions, email me: ian.aflack@gmail.com

**if you make a new toggle graphics, be shure to send them to me so they can be included in my next periodic update**


extra notes & instructions-

	-General: please use an image editor that supports layering such as *gimp (open source) or adobe Photoshop (really overpriced). additionally you should make your graphic in both states (on,off) and 	          in all three styles (stripped, glyphic, and default) 
	
	-layering: 1. the gloss should be the top layer
		   2. your graphic should be in the middle
		   3. the colored base should be the bottom layer