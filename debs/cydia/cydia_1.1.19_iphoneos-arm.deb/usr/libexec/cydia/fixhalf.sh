#!/bin/bash
rm -f /var/lib/dpkg/info/%@.prerm
rm -f /var/lib/dpkg/info/%@.postrm
rm -f /var/lib/dpkg/info/%@.preinst
rm -f /var/lib/dpkg/info/%@.postinst
rm -f /var/lib/dpkg/info/%@.extrainst_
